# simple_task_mngt_crud_backend
TASK MANAGEMENT SYSTEM (Backend) using Laravel 9/MySQL
